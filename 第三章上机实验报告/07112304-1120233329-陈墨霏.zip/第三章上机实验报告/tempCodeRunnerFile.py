        table.item(0, 0).setFlags(Qt.ItemFlag.ItemIsEnabled)
        table.item(rows-1, columns-1).setFlags(Qt.ItemFlag.ItemIsEnabled)